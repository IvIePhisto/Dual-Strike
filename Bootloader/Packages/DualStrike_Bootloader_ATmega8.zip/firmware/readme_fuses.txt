0xC0 high and 0x9f low 

For disablin reset line use

0x40 high and 0x9f low 
