Dual Strike Configuration
=========================
You need the firmware 2.0 installed on your Dual Strike. You also need a Java 6
Runtime Environment (for example from Oracle: http://www.java.com/download/)
installed on your PC. Non-Windows users please read "mcc_Readme.txt".

Start the configuration editor by double-clicking on "mcc-1.1.0.jar".
To load and save the configuration to the Dual Strike you first have to enter
the configuration mode by pressing Select on plugging in. By pressing Start the
configuration mode is left.
