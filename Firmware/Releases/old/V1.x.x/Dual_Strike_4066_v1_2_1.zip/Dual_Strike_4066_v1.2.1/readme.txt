﻿                             Dual Strike v1.0
                                       
                         Copyright 2009 Jochen Zurborg
                                       
                           http://www.zurborg.info

All code, schematics, PCB designs, firmware and other files included with this 
archive are licensed under the GNU Public License V3, see license.txt for more 
details. 



Introduction
============

The Dual Strike PCB is a completely solderless board for your arcade stick. 
Every connection to buttons or directions screw in directly to the side of the board, 
so installation requires nothing more than a screwdriver. 
Dual Strike works on any PC (including Mac, Windows Vista/XP/2K/98, and Linux) as well as Playstation 3 systems.

Thus makes the dual strike the perfect solution for customers who want to build an arcade stick.

Features 
========

    * 20 screw terminal ports for connecting all of your wires
    * No soldering required
    * USB ‘B’ jack for connecting any standard USB cable
    * Piggyback interface for easy installation of additional xbox360 pads
    * Integrated switch interface for easy configuration between xbox360 and PS3
    * Easy to use dual mod interface supporting dreamcast or xbox360
    * Seperate connection points for all power lines and signals
    * Mounting holes for easy installation inside your arcade board
    * Works on PC, PS3 and MAC out of the box
    * Compatible with Windows™ Vista/XP/2000/98 & Linux

How to Use
==========

During plug-in press any play button or stick to switch to PS3. 

Default boot up is piggybacked PCB like xbox360 or dreamcast.

Press Home to use only Digital Stick only.
Press Select to use only Digital Stick only.

Press Start to switch to bootloader.

	
Firmware
========

Firmware source code for AVR Studio and compiled .hex file are included.



History
=======


1.2     - HID Device extended
		- Inverted Trigger Support
		
1.1     - HID Device extended 
		
1.0		- no PS3 Home Button support
