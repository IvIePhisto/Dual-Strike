﻿                             Dual Strike v1.0
                                       
                         Copyright 2009 Jochen Zurborg
                                       
                           http://www.zurborg.info

Version: 1.3

All code, schematics, PCB designs, firmware and other files included with this 
archive are licensed under the GNU Public License V3, see license.txt for more 
details. 

Some modifications to firmware by Michael Pohl


Introduction
============

The Dual Strike PCB is a completely solderless board for your arcade stick. 
Every connection to buttons or directions screw in directly to the side of the board, 
so installation requires nothing more than a screwdriver. 
Dual Strike works on any PC (including Mac, Windows Vista/XP/2K/98, and Linux) as well as Playstation 3 systems.

Thus makes the dual strike the perfect solution for customers who want to build an arcade stick.


Features 
========

    * 20 screw terminal ports for connecting all of your wires
    * No soldering required
    * USB ‘B’ jack for connecting any standard USB cable
    * Piggyback interface for easy installation of additional xbox360 pads
    * Integrated switch interface for easy configuration between xbox360 and PS3
    * Easy to use dual mod interface supporting dreamcast or xbox360
    * Seperate connection points for all power lines and signals
    * Mounting holes for easy installation inside your arcade board
    * Works on PC, PS3 and MAC out of the box
    * Compatible with Windows™ Vista/XP/2000/98 & Linux


How to Use
==========

When shipped the default working mode is Dual Strike.
During plug-in press any play button or stick to switch to the non-default working mode. 


Configuration Mode
==================
Configuration mode is entered by pressing Select on plugging in.
It is left by pressing Start.

While in configuration mode pressing the following buttons will change the configuration:
LK      default working mode: Dual Strike (default, precedence over MK)
MK      default working mode: pass-through
LP      Start+Select=Home: disabled (default, precedence over MP)
MP      Start+Select=Home: enabled
Up      Dual Strike stick mode: both (default, precedence over Left and Right)
Left    Dual Strike stick mode: digital only
Right   Dual Strike stick mode: analogue only

Inverted trigger support is not normally compiled in. But if it is the following configuration
possibilities are also available:
HK      inverted trigger support: disabled (default, precedence over 4P)
4P      inverted trigger support: enabled

	
Firmware
========

Press and hold Start to switch to bootloader, then you can execute the file
"update_firmware.bat" to update the firmware (two command
prompt windows should open).

Firmware source code for AVR Studio and compiled .hex file are included.


History
=======

1.3    - added configuration capabilities
       - PS3 Home Button support
       - inverted trigger support removed from build, still usable through recompilation

1.2    - HID Device extended
       - Inverted Trigger Support
		
1.1    - HID Device extended 
		
1.0    - no PS3 Home Button support
