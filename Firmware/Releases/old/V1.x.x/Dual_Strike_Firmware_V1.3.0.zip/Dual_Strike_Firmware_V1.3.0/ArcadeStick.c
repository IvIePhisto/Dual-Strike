#include <avr/eeprom.h> /* EEPROM functions */
#define EEPROM_DEF 0xFF /* for uninitialized EEPROMS */
uint8_t config = EEPROM_DEF;

/* 
Configuration Mode
==================
Configuration mode is entered by pressing Select on plugging in.
It is left by pressing Start.
While in configuration mode pressing the following buttons will change the configuration:
LK		default working mode: Dual Strike (precedence over MK)
MK		default working mode: pass-through
LP		Start+Select=Home: disabled (precedence over MP)
MP		Start+Select=Home: enabled
HK		inverted trigger support: disabled (precedence over HP)
HP		inverted trigger support: enabled
Up		Dual Strike stick mode: both (precedence over Left and Right)
Left	Dual Strike stick mode: digital only
Right	Dual Strike stick mode: analogue only

config byte description by bits:
--------------------------------
0:   default working mode (0 == Dual Strike; 1 == pass-through
1-2: Dual Strike stick mode (00 == both; 10 == digital only; 01 == analogue only)
3:   Start+Select=Home (0 == disabled, 1 == enabled)
4:   inverted trigger support (0 == disabled, 1 == enabled)
*/
#define CONFIG_DEF 0b00000000 /* default config */
uint8_t config_EEPROM EEMEM = CONFIG_DEF;

unsigned char enforcedWorkingMode = 2; // no working mode enforced

// test configuration: default working mode == Dual Strike
#define CFG_DEF_WORK_MODE_DS 	!(config & (1<<0))
// test configuration: Start+Select=Home == enabled
#define CFG_HOME_EMU		 	(config & (1<<3))

#define INVERTED_TRIGGERS 0
#if INVERTED_TRIGGERS
// test configuration: inverted trigger support == enabled
#define CFG_INV_TR_SUP		 	(config & (1<<4))
#endif
// must be one if INVERTED_TRIGGERS is:
#define EXTRA_BUTTONS 1

#if INVERTED_TRIGGERS
#if EXTRA_BUTTONS
#else
#error If INVERTED_TRIGGERS equals one, EXTRA_BUTTONS must too.
#endif
#endif

#include <avr/io.h>
#include <avr/interrupt.h>  /* for sei() */
#include <util/delay.h>     /* for _delay_ms() */

#include <avr/pgmspace.h>   /* required by usbdrv.h */
#include "usbconfig.h"
#include "usbdrv.h"
	


#define Stick_Up			(PIND & (1<<6))
#define Stick_Down			(PIND & (1<<7))
#define Stick_Left			(PINB & (1<<0))
#define Stick_Right			(PINB & (1<<1))

//PC Button 1 - Square - LP
#define Stick_Jab			(PINB & (1<<2))
//PC Button 4 - Triangle - MP
#define Stick_Strong		(PINB & (1<<5))
//PC Button 6 - R1 - HP
#define Stick_Fierce		(PIND & (1<<5))
//PC Button 2 - Cross - LK
#define Stick_Short			(PINB & (1<<3))
//PC Button 3 - Circle - MK
#define Stick_Forward		(PINB & (1<<4))
//PC Button 8 - R2 - HK
#define Stick_Roundhouse	(PINC & (1<<2))
//PC Button 9 - Select
#define Stick_Select		(PINC & (1<<1))
//PC Button 10 - Start
#define Stick_Start			(PINC & (1<<0))
//PC Button 13 - Home
#define Stick_Home			(PINC & (1<<5))

#ifdef EXTRA_BUTTONS
	//PC Button 5 - L1 - 4P
	#define Stick_Extra0		(PINC & (1<<3))
	//PC Button 7 - L2 - 4K
	#define Stick_Extra1		(PINC & (1<<4))
#endif

//Defines for USB_STICK_MODE. 
#define USM_BOTH 0
#define USM_DIGITAL_ONLY 1
#define USM_ANALOG_ONLY 2

unsigned char USB_STICK_MODE = USM_BOTH;
unsigned char SwitchMode;

/* ------------------------------------------------------------------------- */
/* ----------------------------- USB interface ----------------------------- */
/* ------------------------------------------------------------------------- */

/* ------------------------------------------------------------------------- */

static uchar buffer[8];

usbMsgLen_t usbFunctionSetup(uchar data[8])
{
	usbRequest_t    *rq = (void *)data;

    if((rq->bmRequestType & USBRQ_TYPE_MASK) == USBRQ_TYPE_CLASS) {    /* class request */
		/* wValue: ReportType (highbyte), ReportID (lowbyte) */
        if(rq->bRequest == USBRQ_HID_GET_REPORT) {
			 // set buffer data
			buffer[0] = 33;
			buffer[1] = 38;
			buffer[2] =
			buffer[3] =
			buffer[4] =
			buffer[5] = 
			buffer[6] =
			buffer[7] = 0;
			usbMsgPtr = buffer;

			return 8; // send 8 bytes	
        }
    }

    return 0;   /* default for not implemented requests: return no data back to host */
}

typedef struct {
	uchar	buttons1;
	uchar	buttons2;	
	uchar   hatswitch;
	uchar	x;
	uchar	y;
	uchar	z;
	uchar	rz;
} report_t;

static	report_t reportBuffer;

void resetReportBuffer() {
	reportBuffer.buttons1 =
	reportBuffer.buttons2 = 0;
	reportBuffer.hatswitch = 0x08;
	reportBuffer.x =
	reportBuffer.y =
	reportBuffer.z =
	reportBuffer.rz = 0x80;
}

PROGMEM char usbHidReportDescriptor[] = { // PC HID Report Descriptor
    0x05, 0x01,                    // USAGE_PAGE (Generic Desktop)
    0x09, 0x05,                    // USAGE (Game Pad)
    0xa1, 0x01,                    // COLLECTION (Application)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x25, 0x01,                    //   LOGICAL_MAXIMUM (1)
    0x35, 0x00,                    //   PHYSICAL_MINIMUM (0)
    0x45, 0x01,                    //   PHYSICAL_MAXIMUM (1)
    0x75, 0x01,                    //   REPORT_SIZE (1)
    0x95, 0x0d,                    //   REPORT_COUNT (13)
    0x05, 0x09,                    //   USAGE_PAGE (Button)
    0x19, 0x01,                    //   USAGE_MINIMUM (Button 1)
    0x29, 0x0d,                    //   USAGE_MAXIMUM (Button 13)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
/* report bits: 13x1=13 */
    0x95, 0x03,                    //   REPORT_COUNT (3)
    0x81, 0x01,                    //   INPUT (Cnst,Ary,Abs)
/* report bits: + 3x1=3 */
    0x05, 0x01,                    //   USAGE_PAGE (Generic Desktop)
    0x25, 0x07,                    //   LOGICAL_MAXIMUM (7)
    0x46, 0x3b, 0x01,              //   PHYSICAL_MAXIMUM (315)
    0x75, 0x04,                    //   REPORT_SIZE (4)
    0x95, 0x01,                    //   REPORT_COUNT (1)
    0x65, 0x14,                    //   UNIT (Eng Rot:Angular Pos)
    0x09, 0x39,                    //   USAGE (Hat switch)
    0x81, 0x42,                    //   INPUT (Data,Var,Abs,Null)
/* report bits: + 1x4=4 */
    0x65, 0x00,                    //   UNIT (None)
    0x95, 0x01,                    //   REPORT_COUNT (1)
    0x81, 0x01,                    //   INPUT (Cnst,Ary,Abs)
/* report bits: + 1x4=4 */
    0x26, 0xff, 0x00,              //   LOGICAL_MAXIMUM (255)
    0x46, 0xff, 0x00,              //   PHYSICAL_MAXIMUM (255)
    0x09, 0x30,                    //   USAGE (X)
    0x09, 0x31,                    //   USAGE (Y)
    0x09, 0x32,                    //   USAGE (Z)
    0x09, 0x35,                    //   USAGE (Rz)
    0x75, 0x08,                    //   REPORT_SIZE (8)
    0x95, 0x04,                    //   REPORT_COUNT (4)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
/* report bits: + 4x8=32 */
    0x06, 0x00, 0xff,              //   USAGE_PAGE (Vendor Defined Page 1)
    0x0a, 0x21, 0x26,              //   UNKNOWN
    0x95, 0x08,                    //   REPORT_COUNT (8)
    0xb1, 0x02,                    //   FEATURE (Data,Var,Abs)

    0xc0                           // END_COLLECTION
};

/* ------------------------------------------------------------------------- */

void configInit() {
	uint8_t newConfig;

	config = eeprom_read_byte(&config_EEPROM); /* read config from EEPROM */

	if(config == EEPROM_DEF)
		/* if EEPROM is unitialized set to default config */
        newConfig = CONFIG_DEF;
	else
		newConfig = config;

	if(!Stick_Select) 
	{
		/* enter configuration modification mode */

		for(;;) {
			if(!Stick_Start)
				// exit configuration modification mode
				break;

			if(!Stick_Short)
			{	// default working mode: Dual Strike [precedence]
				newConfig &= ~(1<<0);
				enforcedWorkingMode = 0;
			}
			else if(!Stick_Forward)
			{	// default working mode: pass-through
				newConfig |= (1<<0);
				enforcedWorkingMode = 1;
			}

			if(!Stick_Jab)
				// Start+Select=Home: disabled [precedence]
				newConfig &= ~(1<<3);
			else if(!Stick_Strong)
				// Start+Select=Home: enabled
				newConfig |= (1<<3);

			if(!Stick_Up)
			{	// Dual Strike stick mode: both [precedence]
				newConfig &= ~(1<<1);
				newConfig &= ~(1<<2);
			}
			else if(!Stick_Left)
			{	// Dual Strike stick mode: digital only
				newConfig |= (1<<1);
				newConfig &= ~(1<<2);
			}
			else if(!Stick_Right)
			{	// Dual Strike stick mode: analogue only
				newConfig &= ~(1<<1);
				newConfig |= (1<<2);
			}

#if INVERTED_TRIGGERS
			if(!Stick_Roundhouse) 
				// inverted trigger support: disabled [precedence]
				newConfig &= ~(1<<4);
			else if(!Stick_Extra0)
				// inverted trigger support: enabled
				newConfig |= (1<<4);
#endif
		}
	}

	if(newConfig != config)
	{
		/* if newConfig was changed update configuration */
		eeprom_write_byte(&config_EEPROM, newConfig);
		config = newConfig;
	}

	if((config & (1<<1)) && !(config & (1<<2)))
		USB_STICK_MODE = USM_DIGITAL_ONLY;
	else if(!(config & (1<<1)) && (config & (1<<2)))
		USB_STICK_MODE = USM_ANALOG_ONLY;
	else
		USB_STICK_MODE = USM_BOTH;
}

void setModeDS()
{
	SwitchMode = 0;
}

void setModePT()
{
	PORTD &= ~(1<<0);	//disable ps3 usb
	PORTD |= (1<<3);	//enable pass-through usb
	
	if(CFG_HOME_EMU)
		DDRC |= (1<<5);	// make the home an output

#if INVERTED_TRIGGERS
	if(CFG_INV_TR_SUP)
	{
		//*************requires reset disabled fuse to be true*************

		DDRD |= (1<<4);   //lt invert pin is output
		PORTD &= ~(1<<4); //lt invert pin is low	
	
		DDRC |= (1<<6);		//rt invert pin is output
		PORTC &= ~(1<<6);	//rt invert pin is low
	}
#endif

	SwitchMode = 1;
}

void HardwareInit()
{
	DDRC	= 0b00000000;
	PORTC	= 0b00111111;	// PORTC inputs with pull-ups

	DDRB	= 0b00000000;
	PORTB	= 0b00111111;	// PORTB inputs with pull-ups
	

	DDRD	= 0b00001001;  // only S1 and S2 are outputs
	PORTD	= 0b11110001;

	configInit();

	if(enforcedWorkingMode == 0)
		setModeDS();
	else if(enforcedWorkingMode == 1)
		setModePT();
	else
	{
		if (   (!Stick_Jab)
			|| (!Stick_Strong) 
			|| (!Stick_Fierce)
			|| (!Stick_Short)
			|| (!Stick_Forward)
			|| (!Stick_Roundhouse) 
			|| (!Stick_Up) 
			|| (!Stick_Down) 
			|| (!Stick_Left) 
			|| (!Stick_Right)
			|| (!Stick_Extra0)
			|| (!Stick_Extra1) )
		{
			// if any punch,kick, or joystick direction is held down, then set to non-default mode
			if(CFG_DEF_WORK_MODE_DS)
				setModePT();
			else
				setModeDS();
		}
		else
		{
	        // else set to default mode
			if(CFG_DEF_WORK_MODE_DS)
				setModeDS();
			else
				setModePT();
		}
	}
}

/* ------------------------------------------------------------------------- */

void ReadJoystick()
{
	resetReportBuffer();

	if(USB_STICK_MODE != USM_DIGITAL_ONLY)
	{
		//Joystick Directions
		//Up
		if (!Stick_Up) reportBuffer.y = 0x00;
		//Down
		else if (!Stick_Down) reportBuffer.y = 0xFF;
		//Left

		if (!Stick_Left) reportBuffer.x = 0x00;
		//Right
		else if (!Stick_Right) reportBuffer.x = 0xFF;
	}
	if(USB_STICK_MODE != USM_ANALOG_ONLY)
	{
		if(!Stick_Up)
		{
			if(!Stick_Right) reportBuffer.hatswitch=0x01;
			else if(!Stick_Left) reportBuffer.hatswitch=0x07;
			else reportBuffer.hatswitch=0x00;
		}
		else if(!Stick_Down)
		{
			if(!Stick_Right) reportBuffer.hatswitch=0x03;
			else if(!Stick_Left) reportBuffer.hatswitch=0x05;
			else reportBuffer.hatswitch=0x04;
		}
		else
		{
			//neither up nor down
			if(!Stick_Right) reportBuffer.hatswitch=0x02;
			if(!Stick_Left) reportBuffer.hatswitch=0x06;
		}
	}

	//Buttons
	if(!Stick_Jab) {
		reportBuffer.buttons1 |= 0b00000001;
	} 

	if(!Stick_Short) {
		reportBuffer.buttons1 |= 0b00000010;
	} 

	if(!Stick_Forward) {
		reportBuffer.buttons1 |= 0b00000100;
	} 

	if(!Stick_Strong) {
		reportBuffer.buttons1 |= 0b00001000;
	} 

#ifdef EXTRA_BUTTONS					
	if(!Stick_Extra0) { //4th punch ==L1
		reportBuffer.buttons1 |=0b00010000;
	}

	if(!Stick_Extra1) { //4th kick==L2	
		reportBuffer.buttons1 |=0b01000000;
	}
#endif

	if(!Stick_Fierce) { //Fierce == R1
		reportBuffer.buttons1 |= 0b00100000;
	}

	if(!Stick_Roundhouse) { //Roundhouse == R2
		reportBuffer.buttons1 |= 0b10000000;
	}

	if(CFG_HOME_EMU && !Stick_Start && !Stick_Select /* && Stick_Jab */)
		reportBuffer.buttons2 |= 0b00010000;
	else
	{
		if(!Stick_Start) reportBuffer.buttons2 |=0b00000010;
		if(!Stick_Select) reportBuffer.buttons2 |=0b00000001;
	}

	if(!Stick_Home) reportBuffer.buttons2 |= 0b00010000;
}




/* ------------------------------------------------------------------------- */

int main(void)
{
	HardwareInit();

	if(SwitchMode == 0) // if switched to Dual Strike
	{
	    usbDeviceDisconnect(); /* enforce re-enumeration, do this while interrupts are disabled! */
	    _delay_ms(300UL);/* fake USB disconnect for > 250 ms */
	    usbDeviceConnect();
		usbInit();
	    sei();

	    while(1) { /* main event loop */
	        usbPoll();

	        if(usbInterruptIsReady()){
	            /* called after every poll of the interrupt endpoint */
				ReadJoystick();
	            usbSetInterrupt((void *)&reportBuffer, sizeof(reportBuffer));
	        }
	    }
	}
	else if(SwitchMode == 1) // if switched to pass-through
	{
	    while(1) { /* main event loop */
			if(CFG_HOME_EMU)
			{
				if( (!Stick_Start) &&  (!Stick_Select) )
					//if start and select are pressed then make guide line low
					PORTC &= ~(1<<5);
				else
					//else guide line is high
					PORTC |= (1<<5);
			}

#if INVERTED_TRIGGERS
			if(CFG_INV_TR_SUP)
			{
				// if LT is pressed then invert trigger and make it high (pressed)
				if(!Stick_Extra1)
				{
					DDRD &= ~(1<<4); //pin is input
					PORTD |= (1<<4); //pin is high
				}
				// else keep xbox trigger low
				else
				{
					DDRD |= (1<<4);   //pin is output
					PORTD &= ~(1<<4); //pin is low
				}
			
				// if RT is pressed then invert trigger and make it high (pressed)
				if(!Stick_Roundhouse)
				{
					DDRC &= ~(1<<6);
					PORTC |= (1<<6);
				}
				// else keep trigger low
				else
				{
					DDRC |= (1<<6);
					PORTC &= ~(1<<6);
				}
			}
#endif
	    }
	}

    return 0;
}
