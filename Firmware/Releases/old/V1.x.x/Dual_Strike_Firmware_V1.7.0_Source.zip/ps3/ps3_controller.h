#ifndef __ps3_controller_h_included__
#define __ps3_controller_h_included__

void ps3_controller();

#endif
