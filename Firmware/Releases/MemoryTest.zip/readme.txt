Dual Strike Memory Test
=======================

This program tests the Dual Strike's flash and EEPROM memory for errors.

If you have an ATmega8 based Dual Strike (V1, earlier SMD) then execute
"memory_test_atmega8.bat". Otherwise you have an ATmega168 based Dual Strike
(V2 and newer, newer SMD, TEasy Strike), execute "memory_test_atmega168.bat".
Follow the instructions displayed.
