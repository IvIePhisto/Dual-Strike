﻿                             Dual Strike v1.0
                                       
                         Copyright 2009 Jochen Zurborg
                                       
                           http://www.zurborg.info

All code, schematics, PCB designs, firmware and other files included with this 
archive are licensed under the GNU Public License V3, see license.txt for more 
details. 

Some modifications to firmware by Michael Pohl

History
=======
1.5    -changed configuration mode behaviour
       -added possibility to reset to the defaults

1.4    - added right stick support
       - removed configuration possibility of inverted triggers
       
1.3    - added configuration capabilities
       - PS3 Home Button support
       - inverted trigger support removed from build, still usable through 
         recompilation

1.2    - HID Device extended
       - Inverted Trigger Support
		
1.1    - HID Device extended 
		
1.0    - initial release


Introduction
============
The Dual Strike PCB is a completely solderless board for your arcade stick.
Every connection to buttons or directions screw in directly to the side of the
board, so installation requires nothing more than a screwdriver. Dual Strike
works on any PC (including Mac, Windows Vista/XP/2K/98, and Linux) as well as
Playstation 3 systems.

This makes the dual strike the perfect solution for customers who want to build 
an arcade stick.


Features 
========
    * 20 screw terminal ports for connecting all of your wires
    * No soldering required
    * USB ‘B’ jack for connecting any standard USB cable
    * Piggyback interface for easy installation of additional xbox360 pads
    * Integrated switch interface for easy configuration between xbox360 and PS3
    * Easy to use dual mod interface supporting dreamcast or xbox360
    * Seperate connection points for all power lines and signals
    * Mounting holes for easy installation inside your arcade board
    * Works on PC, PS3 and MAC out of the box
    * Compatible with Windows™ Vista/XP/2000/98 & Linux


Startup Behaviour
=================
If a button or joystick direction is pressed, when the Dual Strike controller
is activated (if the machine it is plugged in is turned on or the controller 
gets plugged into the machine), then special functions are activated:

If the Select button is pressed, then configuration mode is entered (see below).

If the Start button is pressed, then firmware update mode is entered (see 
Firmware).

If any other Button except Home is pressed, then the non default working mode is
entered. The working mode is either the Dual Strike acting as a controller 
(default) or pass-through (e.g. a XBox360 controller PCB).

If the joystick is moved to the up direction, the joystick is acting as a
digital pad when in Dual Strike working mode (default).
If the joystick is moved to the left direction, the joystick is acting as a left
analogue stick when in Dual Strike working mode.
If the joystick is moved to the right direction, the joystick is acting as a
right analogue stick when in Dual Strike working mode.

Configuration Mode
==================
In the configuration mode the behaviour of the Dual Strike can be changed, see 
Startup Behaviour for how to enter it. Leave it by pressing Start.

While in configuration mode pressing the following buttons will change the 
configuration:

Default Working Mode:
---------------------
LK  Dual Strike (precedence over MK) [default]
MK  pass-through

Start+Select=Home:
------------------
LP  disabled (precedence over MP) [default]
MP  enabled

revert to defaults:
-------------------
HP

Dual Strike Default Stick Mode:
-------------------------------
Up     digital pad only (precedence over Left and Right) [default]
Left   left analogue stick only
Right  right analogue stick only
Down   activate digital pad additionallly to left or right analogue stick

	
Firmware
========

To update the firmware of your Dual Strike press and hold Start to switch to
the firmware update mode, then you can execute the file "update_firmware.bat" to
update the firmware (two command prompt windows should open). After releasing 
the Start button, firmware update mode is left.

Firmware source code for AVR Studio and compiled .hex file are included.

A special firmware with inverted triggers support is available on request.

