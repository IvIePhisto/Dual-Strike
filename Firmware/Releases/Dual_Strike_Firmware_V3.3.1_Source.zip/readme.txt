﻿								  Dual Strike
                                       
                         Copyright 2009 Jochen Zurborg
                                       
                           http://www.zurborg.info

All code, schematics, firmware and other files included within this
archive are licensed under the GNU Public License V3, see license.txt for more
details.

Introduction
============
The Dual Strike is a project of a easy-to-use controller PCB. Dual Strike
works on any PC (including Mac, Windows 7/Vista/XP/2K/98, and Linux) as well as
Playstation 3 systems.

This makes the dual strike the perfect solution for customers who want to build 
an arcade stick.

Contents
========
The files within this archive are the source code of the Dual Strike and its SMD
design as an AVR Studio project.

For more information visit:
<http://docs.google.com/document/preview?id=1kSNxb2SLDZB-jQpl1ZHbVoksGS7_nDJKFOAMJo3S_tA>

