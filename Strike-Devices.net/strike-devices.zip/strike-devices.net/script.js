/*
 * STRIKE-DEVICES.NET Design
 * =========================
 * Copyright 2011 by Michael Pohl
 */

/* cookie handling */

function createCookie(name, value, days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name,"",-1);
}

/* version switcher */

var viewportWidth = $(window).width();
var viewportHeight = $(window).height();

function orientationChange() {
  var temp = viewportWidth;
  viewportWidth = viewportHeight;
  viewportHeight = temp;
}

function initViewportWidth() {
  var deviceWidth = $(window).width();
  
  if(viewportWidth == deviceWidth)
    viewportWidth = null;
}

var version = readCookie("version");

if(version == null)
  version = (screen.width <= 480)?"mobile":"desktop";

function activateSwitcher(id, switchFunction) {
  var switcher = $("#" + id);
  var text = switcher.text();
  switcher.replaceWith('<a href="" id="' + id + '" class="inactive-version">' +  text + '</a>');
  switcher = $("#" + id);
  switcher.click(switchFunction);
}

function set2mobile() {
  if(viewportWidth != null)
    $("#viewport").attr("content", "width=device-width");
    
  $("#primary").hide();
  $("#stylesheet_mobile").attr("rel", "stylesheet");
  $("#stylesheet_print").removeAttr("rel");
  $("#primary").show();
  activateSwitcher("switch2normal", switch2normal);
  activateSwitcher("switch2print", switch2print);
}

function set2normal() {
  if(viewportWidth != null)
    $("#viewport").attr("content", "width=" + viewportWidth);
    
  $("#stylesheet_mobile").removeAttr("rel");
  $("#stylesheet_print").removeAttr("rel");
  activateSwitcher("switch2mobile", switch2mobile);
  activateSwitcher("switch2print", switch2print);
}

function set2print() {
  if(viewportWidth != null)
    $("#viewport").attr("content", "width=" + viewportWidth);
    
  $("#stylesheet_mobile").removeAttr("rel");
  $("#stylesheet_print").attr("rel", "stylesheet");
  activateSwitcher("switch2mobile", switch2mobile);
  activateSwitcher("switch2normal", switch2normal);
  
  var previousVersion = readCookie("previousVersion");
  
  if(previousVersion == null)
      eraseCookie("version");
  else {
      createCookie("version", previousVersion);
      eraseCookie("previous-version");
  }
}

function switch2mobile() {
  createCookie("version", "mobile", 1);
}

function switch2normal() {
  createCookie("version", "normal", 1);
}

function switch2print() {
  createCookie("previousVersion", version, 1);
  createCookie("version", "print", 1);
}


/* size controls */

var baseSize = 0;
var relativeSize = readCookie("relativeSize");

if(relativeSize == null)
  relativeSize = 0;
else
  relativeSize = parseInt(relativeSize);

function applySize() {
  var currentSizeViewer = $("#size-current");
  
  currentSizeViewer.children("span").text((relativeSize>0?"+":"") + relativeSize);

  if(relativeSize == 0)
    currentSizeViewer.hide();
  else
    currentSizeViewer.show();
    
  var fontSize = 100 + relativeSize;
  $("body").css("font-size", fontSize + "%");
}

function sizeAdjust(delta) {
  if(delta == 0)
    relativeSize = 0;
  else
    relativeSize += delta;
  
  createCookie("relativeSize", relativeSize, 1);
  applySize();
}

function sizeDecrease() {
  sizeAdjust(-5);
}

function sizeReset() {
  sizeAdjust(0);
}

function sizeIncrease() {
  sizeAdjust(+5);
}


/* touch support */

function setTouched() {
  $(this).removeClass("untouched");
  $(this).addClass("touched");
}

function setUntouched() {
  $(this).removeClass("touched");
  $(this).addClass("untouched");
}


/* initialization on document load */

function initViewControls() {  
  if(version == "mobile")
    set2mobile();
  else if(version == "print")
    set2print();
  else
    set2normal();

  $("#stylesheet_mobile").removeAttr("media");
  $("#stylesheet_print").removeAttr("media");
  baseSize = parseFloat($("body").css("font-size"));
  
  if(relativeSize != 0)
    applySize();

  $("#view-controls").show();
}

$(document).ready(function() {
  initViewControls();
  window.scrollTo(0, 1);
  
  var touchTargets = $("#primary ul li a");
  touchTargets.bind("touchstart", setTouched);
  touchTargets.bind("touchend", setUntouched);
  touchTargets.bind("touchcancel", setUntouched);

  touchTargets = $("#secondary ul li a");
  touchTargets.bind("touchstart", setTouched);
  touchTargets.bind("touchend", setUntouched);
  touchTargets.bind("touchcancel", setUntouched);

  touchTargets = $(".menu ul li a");
  touchTargets.bind("touchstart", setTouched);
  touchTargets.bind("touchend", setUntouched);
  touchTargets.bind("touchcancel", setUntouched);

  touchTargets = $("#searchform input");
  touchTargets.bind("touchstart", setTouched);
  touchTargets.bind("touchend", setUntouched);
  touchTargets.bind("touchcancel", setUntouched);

  touchTargets = $("#view-controls button");
  touchTargets.bind("touchstart", setTouched);
  touchTargets.bind("touchend", setUntouched);
  touchTargets.bind("touchcancel", setUntouched);
});

