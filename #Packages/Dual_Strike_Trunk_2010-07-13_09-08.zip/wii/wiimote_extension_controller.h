#ifndef __wiimote_extension_controller_h_included__
#define __wiimote_extension_controller_h_included__

void wiimote_extension_controller();

#endif
