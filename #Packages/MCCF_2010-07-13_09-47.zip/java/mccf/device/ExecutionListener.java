package mccf.device;

public interface ExecutionListener {
	public void executionFinished(ExecutionResult result);
}
